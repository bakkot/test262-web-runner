// Reviewed
//@ skip

let length = 0x10001000;

let foo = new Array(length);
foo.concat(1);
