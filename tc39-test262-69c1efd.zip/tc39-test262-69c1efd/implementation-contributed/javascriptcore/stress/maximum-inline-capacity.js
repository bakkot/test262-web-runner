// test maximum inline capacity inferred for narrow instructions

function test1() {
    ({
        property1: 1,
        property2: 2,
        property3: 3,
        property4: 4,
        property5: 5,
        property6: 6,
        property7: 7,
        property8: 8,
        property9: 9,
        property10: 10,
        property11: 11,
        property12: 12,
        property13: 13,
        property14: 14,
        property15: 15,
        property16: 16,
        property17: 17,
        property18: 18,
        property19: 19,
        property20: 20,
        property21: 21,
        property22: 22,
        property23: 23,
        property24: 24,
        property25: 25,
        property26: 26,
        property27: 27,
        property28: 28,
        property29: 29,
        property30: 30,
        property31: 31,
        property32: 32,
        property33: 33,
        property34: 34,
        property35: 35,
        property36: 36,
        property37: 37,
        property38: 38,
        property39: 39,
        property40: 40,
        property41: 41,
        property42: 42,
        property43: 43,
        property44: 44,
        property45: 45,
        property46: 46,
        property47: 47,
        property48: 48,
        property49: 49,
        property50: 50,
        property51: 51,
        property52: 52,
        property53: 53,
        property54: 54,
        property55: 55,
        property56: 56,
        property57: 57,
        property58: 58,
        property59: 59,
        property60: 60,
        property61: 61,
        property62: 62,
        property63: 63,
        property64: 64,
        property65: 65,
        property66: 66,
        property67: 67,
        property68: 68,
        property69: 69,
        property70: 70,
        property71: 71,
        property72: 72,
        property73: 73,
        property74: 74,
        property75: 75,
        property76: 76,
        property77: 77,
        property78: 78,
        property79: 79,
        property80: 80,
        property81: 81,
        property82: 82,
        property83: 83,
        property84: 84,
        property85: 85,
        property86: 86,
        property87: 87,
        property88: 88,
        property89: 89,
        property90: 90,
        property91: 91,
        property92: 92,
        property93: 93,
        property94: 94,
        property95: 95,
        property96: 96,
        property97: 97,
        property98: 98,
        property99: 99,
        property100: 100,
        property101: 101,
        property102: 102,
        property103: 103,
        property104: 104,
        property105: 105,
        property106: 106,
        property107: 107,
        property108: 108,
        property109: 109,
        property110: 110,
        property111: 111,
        property112: 112,
        property113: 113,
        property114: 114,
        property115: 115,
        property116: 116,
        property117: 117,
        property118: 118,
        property119: 119,
        property120: 120,
        property121: 121,
        property122: 122,
        property123: 123,
        property124: 124,
        property125: 125,
        property126: 126,
        property127: 127,
        property128: 128,
        property129: 129,
        property130: 130,
        property131: 131,
        property132: 132,
        property133: 133,
        property134: 134,
        property135: 135,
        property136: 136,
        property137: 137,
        property138: 138,
        property139: 139,
        property140: 140,
        property141: 141,
        property142: 142,
        property143: 143,
        property144: 144,
        property145: 145,
        property146: 146,
        property147: 147,
        property148: 148,
        property149: 149,
        property150: 150,
        property151: 151,
        property152: 152,
        property153: 153,
        property154: 154,
        property155: 155,
        property156: 156,
        property157: 157,
        property158: 158,
        property159: 159,
        property160: 160,
        property161: 161,
        property162: 162,
        property163: 163,
        property164: 164,
        property165: 165,
        property166: 166,
        property167: 167,
        property168: 168,
        property169: 169,
        property170: 170,
        property171: 171,
        property172: 172,
        property173: 173,
        property174: 174,
        property175: 175,
        property176: 176,
        property177: 177,
        property178: 178,
        property179: 179,
        property180: 180,
        property181: 181,
        property182: 182,
        property183: 183,
        property184: 184,
        property185: 185,
        property186: 186,
        property187: 187,
        property188: 188,
        property189: 189,
        property190: 190,
        property191: 191,
        property192: 192,
        property193: 193,
        property194: 194,
        property195: 195,
        property196: 196,
        property197: 197,
        property198: 198,
        property199: 199,
        property200: 200,
        property201: 201,
        property202: 202,
        property203: 203,
        property204: 204,
        property205: 205,
        property206: 206,
        property207: 207,
        property208: 208,
        property209: 209,
        property210: 210,
        property211: 211,
        property212: 212,
        property213: 213,
        property214: 214,
        property215: 215,
        property216: 216,
        property217: 217,
        property218: 218,
        property219: 219,
        property220: 220,
        property221: 221,
        property222: 222,
        property223: 223,
        property224: 224,
        property225: 225,
        property226: 226,
        property227: 227,
        property228: 228,
        property229: 229,
        property230: 230,
        property231: 231,
        property232: 232,
        property233: 233,
        property234: 234,
        property235: 235,
        property236: 236,
        property237: 237,
        property238: 238,
        property239: 239,
        property240: 240,
        property241: 241,
        property242: 242,
        property243: 243,
        property244: 244,
        property245: 245,
        property246: 246,
        property247: 247,
        property248: 248,
        property249: 249,
        property250: 250,
        property251: 251,
        property252: 252,
        property253: 253,
        property254: 254,
        property255: 255,
        property256: 256,
        property257: 257,
        property258: 258,
        property259: 259,
        property260: 260,
        property261: 261,
        property262: 262,
        property263: 263,
        property264: 264,
        property265: 265,
        property266: 266,
        property267: 267,
        property268: 268,
        property269: 269,
        property270: 270,
        property271: 271,
        property272: 272,
        property273: 273,
        property274: 274,
        property275: 275,
        property276: 276,
        property277: 277,
        property278: 278,
        property279: 279,
        property280: 280,
        property281: 281,
        property282: 282,
        property283: 283,
        property284: 284,
        property285: 285,
        property286: 286,
        property287: 287,
        property288: 288,
        property289: 289,
        property290: 290,
        property291: 291,
        property292: 292,
        property293: 293,
        property294: 294,
        property295: 295,
        property296: 296,
        property297: 297,
        property298: 298,
        property299: 299,
        property300: 300,
        property301: 301,
        property302: 302,
        property303: 303,
        property304: 304,
        property305: 305,
        property306: 306,
        property307: 307,
        property308: 308,
        property309: 309,
        property310: 310,
        property311: 311,
        property312: 312,
        property313: 313,
        property314: 314,
        property315: 315,
        property316: 316,
        property317: 317,
        property318: 318,
        property319: 319,
        property320: 320,
        property321: 321,
        property322: 322,
        property323: 323,
        property324: 324,
        property325: 325,
        property326: 326,
        property327: 327,
        property328: 328,
        property329: 329,
        property330: 330,
        property331: 331,
        property332: 332,
        property333: 333,
        property334: 334,
        property335: 335,
        property336: 336,
        property337: 337,
        property338: 338,
        property339: 339,
        property340: 340,
        property341: 341,
        property342: 342,
        property343: 343,
        property344: 344,
        property345: 345,
        property346: 346,
        property347: 347,
        property348: 348,
        property349: 349,
        property350: 350,
        property351: 351,
        property352: 352,
        property353: 353,
        property354: 354,
        property355: 355,
        property356: 356,
        property357: 357,
        property358: 358,
        property359: 359,
        property360: 360,
        property361: 361,
        property362: 362,
        property363: 363,
        property364: 364,
        property365: 365,
        property366: 366,
        property367: 367,
        property368: 368,
        property369: 369,
        property370: 370,
        property371: 371,
        property372: 372,
        property373: 373,
        property374: 374,
        property375: 375,
        property376: 376,
        property377: 377,
        property378: 378,
        property379: 379,
        property380: 380,
        property381: 381,
        property382: 382,
        property383: 383,
        property384: 384,
        property385: 385,
        property386: 386,
        property387: 387,
        property388: 388,
        property389: 389,
        property390: 390,
        property391: 391,
        property392: 392,
        property393: 393,
        property394: 394,
        property395: 395,
        property396: 396,
        property397: 397,
        property398: 398,
        property399: 399,
        property400: 400,
        property401: 401,
        property402: 402,
        property403: 403,
        property404: 404,
        property405: 405,
        property406: 406,
        property407: 407,
        property408: 408,
        property409: 409,
        property410: 410,
        property411: 411,
        property412: 412,
        property413: 413,
        property414: 414,
        property415: 415,
        property416: 416,
        property417: 417,
        property418: 418,
        property419: 419,
        property420: 420,
        property421: 421,
        property422: 422,
        property423: 423,
        property424: 424,
        property425: 425,
        property426: 426,
        property427: 427,
        property428: 428,
        property429: 429,
        property430: 430,
        property431: 431,
        property432: 432,
        property433: 433,
        property434: 434,
        property435: 435,
        property436: 436,
        property437: 437,
        property438: 438,
        property439: 439,
        property440: 440,
        property441: 441,
        property442: 442,
        property443: 443,
        property444: 444,
        property445: 445,
        property446: 446,
        property447: 447,
        property448: 448,
        property449: 449,
        property450: 450,
        property451: 451,
        property452: 452,
        property453: 453,
        property454: 454,
        property455: 455,
        property456: 456,
        property457: 457,
        property458: 458,
        property459: 459,
        property460: 460,
        property461: 461,
        property462: 462,
        property463: 463,
        property464: 464,
        property465: 465,
        property466: 466,
        property467: 467,
        property468: 468,
        property469: 469,
        property470: 470,
        property471: 471,
        property472: 472,
        property473: 473,
        property474: 474,
        property475: 475,
        property476: 476,
        property477: 477,
        property478: 478,
        property479: 479,
        property480: 480,
        property481: 481,
        property482: 482,
        property483: 483,
        property484: 484,
        property485: 485,
        property486: 486,
        property487: 487,
        property488: 488,
        property489: 489,
        property490: 490,
        property491: 491,
        property492: 492,
        property493: 493,
        property494: 494,
        property495: 495,
        property496: 496,
        property497: 497,
        property498: 498,
        property499: 499,
        property500: 500,
        property501: 501,
        property502: 502,
        property503: 503,
        property504: 504,
        property505: 505,
        property506: 506,
        property507: 507,
        property508: 508,
        property509: 509,
        property510: 510,
        property511: 511,
        property512: 512,
        property513: 513,
        property514: 514,
        property515: 515,
        property516: 516,
        property517: 517,
        property518: 518,
        property519: 519,
        property520: 520,
        property521: 521,
        property522: 522,
        property523: 523,
        property524: 524,
        property525: 525,
        property526: 526,
        property527: 527,
        property528: 528,
        property529: 529,
        property530: 530,
        property531: 531,
        property532: 532,
        property533: 533,
        property534: 534,
        property535: 535,
        property536: 536,
        property537: 537,
        property538: 538,
        property539: 539,
        property540: 540,
        property541: 541,
        property542: 542,
        property543: 543,
        property544: 544,
        property545: 545,
        property546: 546,
        property547: 547,
        property548: 548,
        property549: 549,
        property550: 550,
        property551: 551,
        property552: 552,
        property553: 553,
        property554: 554,
        property555: 555,
        property556: 556,
        property557: 557,
        property558: 558,
        property559: 559,
        property560: 560,
        property561: 561,
        property562: 562,
        property563: 563,
        property564: 564,
        property565: 565,
        property566: 566,
        property567: 567,
        property568: 568,
        property569: 569,
        property570: 570,
        property571: 571,
        property572: 572,
        property573: 573,
        property574: 574,
        property575: 575,
        property576: 576,
        property577: 577,
        property578: 578,
        property579: 579,
        property580: 580,
        property581: 581,
        property582: 582,
        property583: 583,
        property584: 584,
        property585: 585,
        property586: 586,
        property587: 587,
        property588: 588,
        property589: 589,
        property590: 590,
        property591: 591,
        property592: 592,
        property593: 593,
        property594: 594,
        property595: 595,
        property596: 596,
        property597: 597,
        property598: 598,
        property599: 599,
        property600: 600,
        property601: 601,
        property602: 602,
        property603: 603,
        property604: 604,
        property605: 605,
        property606: 606,
        property607: 607,
        property608: 608,
        property609: 609,
        property610: 610,
        property611: 611,
        property612: 612,
        property613: 613,
        property614: 614,
        property615: 615,
        property616: 616,
        property617: 617,
        property618: 618,
        property619: 619,
        property620: 620,
        property621: 621,
        property622: 622,
        property623: 623,
        property624: 624,
        property625: 625,
        property626: 626,
        property627: 627,
        property628: 628,
        property629: 629,
        property630: 630,
        property631: 631,
        property632: 632,
        property633: 633,
        property634: 634,
        property635: 635,
        property636: 636,
        property637: 637,
        property638: 638,
        property639: 639,
        property640: 640,
        property641: 641,
        property642: 642,
        property643: 643,
        property644: 644,
        property645: 645,
        property646: 646,
        property647: 647,
        property648: 648,
        property649: 649,
        property650: 650,
        property651: 651,
        property652: 652,
        property653: 653,
        property654: 654,
        property655: 655,
        property656: 656,
        property657: 657,
        property658: 658,
        property659: 659,
        property660: 660,
        property661: 661,
        property662: 662,
        property663: 663,
        property664: 664,
        property665: 665,
        property666: 666,
        property667: 667,
        property668: 668,
        property669: 669,
        property670: 670,
        property671: 671,
        property672: 672,
        property673: 673,
        property674: 674,
        property675: 675,
        property676: 676,
        property677: 677,
        property678: 678,
        property679: 679,
        property680: 680,
        property681: 681,
        property682: 682,
        property683: 683,
        property684: 684,
        property685: 685,
        property686: 686,
        property687: 687,
        property688: 688,
        property689: 689,
        property690: 690,
        property691: 691,
        property692: 692,
        property693: 693,
        property694: 694,
        property695: 695,
        property696: 696,
        property697: 697,
        property698: 698,
        property699: 699,
        property700: 700,
        property701: 701,
        property702: 702,
        property703: 703,
        property704: 704,
        property705: 705,
        property706: 706,
        property707: 707,
        property708: 708,
        property709: 709,
        property710: 710,
        property711: 711,
        property712: 712,
        property713: 713,
        property714: 714,
        property715: 715,
        property716: 716,
        property717: 717,
        property718: 718,
        property719: 719,
        property720: 720,
        property721: 721,
        property722: 722,
        property723: 723,
        property724: 724,
        property725: 725,
        property726: 726,
        property727: 727,
        property728: 728,
        property729: 729,
        property730: 730,
        property731: 731,
        property732: 732,
        property733: 733,
        property734: 734,
        property735: 735,
        property736: 736,
        property737: 737,
        property738: 738,
        property739: 739,
        property740: 740,
        property741: 741,
        property742: 742,
        property743: 743,
        property744: 744,
        property745: 745,
        property746: 746,
        property747: 747,
        property748: 748,
        property749: 749,
        property750: 750,
        property751: 751,
        property752: 752,
        property753: 753,
        property754: 754,
        property755: 755,
        property756: 756,
        property757: 757,
        property758: 758,
        property759: 759,
        property760: 760,
        property761: 761,
        property762: 762,
        property763: 763,
        property764: 764,
        property765: 765,
        property766: 766,
        property767: 767,
        property768: 768,
        property769: 769,
        property770: 770,
        property771: 771,
        property772: 772,
        property773: 773,
        property774: 774,
        property775: 775,
        property776: 776,
        property777: 777,
        property778: 778,
        property779: 779,
        property780: 780,
        property781: 781,
        property782: 782,
        property783: 783,
        property784: 784,
        property785: 785,
        property786: 786,
        property787: 787,
        property788: 788,
        property789: 789,
        property790: 790,
        property791: 791,
        property792: 792,
        property793: 793,
        property794: 794,
        property795: 795,
        property796: 796,
        property797: 797,
        property798: 798,
        property799: 799,
        property800: 800,
        property801: 801,
        property802: 802,
        property803: 803,
        property804: 804,
        property805: 805,
        property806: 806,
        property807: 807,
        property808: 808,
        property809: 809,
        property810: 810,
        property811: 811,
        property812: 812,
        property813: 813,
        property814: 814,
        property815: 815,
        property816: 816,
        property817: 817,
        property818: 818,
        property819: 819,
        property820: 820,
        property821: 821,
        property822: 822,
        property823: 823,
        property824: 824,
        property825: 825,
        property826: 826,
        property827: 827,
        property828: 828,
        property829: 829,
        property830: 830,
        property831: 831,
        property832: 832,
        property833: 833,
        property834: 834,
        property835: 835,
        property836: 836,
        property837: 837,
        property838: 838,
        property839: 839,
        property840: 840,
        property841: 841,
        property842: 842,
        property843: 843,
        property844: 844,
        property845: 845,
        property846: 846,
        property847: 847,
        property848: 848,
        property849: 849,
        property850: 850,
        property851: 851,
        property852: 852,
        property853: 853,
        property854: 854,
        property855: 855,
        property856: 856,
        property857: 857,
        property858: 858,
        property859: 859,
        property860: 860,
        property861: 861,
        property862: 862,
        property863: 863,
        property864: 864,
        property865: 865,
        property866: 866,
        property867: 867,
        property868: 868,
        property869: 869,
        property870: 870,
        property871: 871,
        property872: 872,
        property873: 873,
        property874: 874,
        property875: 875,
        property876: 876,
        property877: 877,
        property878: 878,
        property879: 879,
        property880: 880,
        property881: 881,
        property882: 882,
        property883: 883,
        property884: 884,
        property885: 885,
        property886: 886,
        property887: 887,
        property888: 888,
        property889: 889,
        property890: 890,
        property891: 891,
        property892: 892,
        property893: 893,
        property894: 894,
        property895: 895,
        property896: 896,
        property897: 897,
        property898: 898,
        property899: 899,
        property900: 900,
        property901: 901,
        property902: 902,
        property903: 903,
        property904: 904,
        property905: 905,
        property906: 906,
        property907: 907,
        property908: 908,
        property909: 909,
        property910: 910,
        property911: 911,
        property912: 912,
        property913: 913,
        property914: 914,
        property915: 915,
        property916: 916,
        property917: 917,
        property918: 918,
        property919: 919,
        property920: 920,
        property921: 921,
        property922: 922,
        property923: 923,
        property924: 924,
        property925: 925,
        property926: 926,
        property927: 927,
        property928: 928,
        property929: 929,
        property930: 930,
        property931: 931,
        property932: 932,
        property933: 933,
        property934: 934,
        property935: 935,
        property936: 936,
        property937: 937,
        property938: 938,
        property939: 939,
        property940: 940,
        property941: 941,
        property942: 942,
        property943: 943,
        property944: 944,
        property945: 945,
        property946: 946,
        property947: 947,
        property948: 948,
        property949: 949,
        property950: 950,
        property951: 951,
        property952: 952,
        property953: 953,
        property954: 954,
        property955: 955,
        property956: 956,
        property957: 957,
        property958: 958,
        property959: 959,
        property960: 960,
        property961: 961,
        property962: 962,
        property963: 963,
        property964: 964,
        property965: 965,
        property966: 966,
        property967: 967,
        property968: 968,
        property969: 969,
        property970: 970,
        property971: 971,
        property972: 972,
        property973: 973,
        property974: 974,
        property975: 975,
        property976: 976,
        property977: 977,
        property978: 978,
        property979: 979,
        property980: 980,
        property981: 981,
        property982: 982,
        property983: 983,
        property984: 984,
        property985: 985,
        property986: 986,
        property987: 987,
        property988: 988,
        property989: 989,
        property990: 990,
        property991: 991,
        property992: 992,
        property993: 993,
        property994: 994,
        property995: 995,
        property996: 996,
        property997: 997,
        property998: 998,
        property999: 999,
        property1000: 1000,
    });
}

function test2() {
    var o = {};
    o.property1 = 1;
    o.property2 = 2;
    o.property3 = 3;
    o.property4 = 4;
    o.property5 = 5;
    o.property6 = 6;
    o.property7 = 7;
    o.property8 = 8;
    o.property9 = 9;
    o.property10 = 10;
    o.property11 = 11;
    o.property12 = 12;
    o.property13 = 13;
    o.property14 = 14;
    o.property15 = 15;
    o.property16 = 16;
    o.property17 = 17;
    o.property18 = 18;
    o.property19 = 19;
    o.property20 = 20;
    o.property21 = 21;
    o.property22 = 22;
    o.property23 = 23;
    o.property24 = 24;
    o.property25 = 25;
    o.property26 = 26;
    o.property27 = 27;
    o.property28 = 28;
    o.property29 = 29;
    o.property30 = 30;
    o.property31 = 31;
    o.property32 = 32;
    o.property33 = 33;
    o.property34 = 34;
    o.property35 = 35;
    o.property36 = 36;
    o.property37 = 37;
    o.property38 = 38;
    o.property39 = 39;
    o.property40 = 40;
    o.property41 = 41;
    o.property42 = 42;
    o.property43 = 43;
    o.property44 = 44;
    o.property45 = 45;
    o.property46 = 46;
    o.property47 = 47;
    o.property48 = 48;
    o.property49 = 49;
    o.property50 = 50;
    o.property51 = 51;
    o.property52 = 52;
    o.property53 = 53;
    o.property54 = 54;
    o.property55 = 55;
    o.property56 = 56;
    o.property57 = 57;
    o.property58 = 58;
    o.property59 = 59;
    o.property60 = 60;
    o.property61 = 61;
    o.property62 = 62;
    o.property63 = 63;
    o.property64 = 64;
    o.property65 = 65;
    o.property66 = 66;
    o.property67 = 67;
    o.property68 = 68;
    o.property69 = 69;
    o.property70 = 70;
    o.property71 = 71;
    o.property72 = 72;
    o.property73 = 73;
    o.property74 = 74;
    o.property75 = 75;
    o.property76 = 76;
    o.property77 = 77;
    o.property78 = 78;
    o.property79 = 79;
    o.property80 = 80;
    o.property81 = 81;
    o.property82 = 82;
    o.property83 = 83;
    o.property84 = 84;
    o.property85 = 85;
    o.property86 = 86;
    o.property87 = 87;
    o.property88 = 88;
    o.property89 = 89;
    o.property90 = 90;
    o.property91 = 91;
    o.property92 = 92;
    o.property93 = 93;
    o.property94 = 94;
    o.property95 = 95;
    o.property96 = 96;
    o.property97 = 97;
    o.property98 = 98;
    o.property99 = 99;
    o.property100 = 100;
    o.property101 = 101;
    o.property102 = 102;
    o.property103 = 103;
    o.property104 = 104;
    o.property105 = 105;
    o.property106 = 106;
    o.property107 = 107;
    o.property108 = 108;
    o.property109 = 109;
    o.property110 = 110;
    o.property111 = 111;
    o.property112 = 112;
    o.property113 = 113;
    o.property114 = 114;
    o.property115 = 115;
    o.property116 = 116;
    o.property117 = 117;
    o.property118 = 118;
    o.property119 = 119;
    o.property120 = 120;
    o.property121 = 121;
    o.property122 = 122;
    o.property123 = 123;
    o.property124 = 124;
    o.property125 = 125;
    o.property126 = 126;
    o.property127 = 127;
    o.property128 = 128;
    o.property129 = 129;
    o.property130 = 130;
    o.property131 = 131;
    o.property132 = 132;
    o.property133 = 133;
    o.property134 = 134;
    o.property135 = 135;
    o.property136 = 136;
    o.property137 = 137;
    o.property138 = 138;
    o.property139 = 139;
    o.property140 = 140;
    o.property141 = 141;
    o.property142 = 142;
    o.property143 = 143;
    o.property144 = 144;
    o.property145 = 145;
    o.property146 = 146;
    o.property147 = 147;
    o.property148 = 148;
    o.property149 = 149;
    o.property150 = 150;
    o.property151 = 151;
    o.property152 = 152;
    o.property153 = 153;
    o.property154 = 154;
    o.property155 = 155;
    o.property156 = 156;
    o.property157 = 157;
    o.property158 = 158;
    o.property159 = 159;
    o.property160 = 160;
    o.property161 = 161;
    o.property162 = 162;
    o.property163 = 163;
    o.property164 = 164;
    o.property165 = 165;
    o.property166 = 166;
    o.property167 = 167;
    o.property168 = 168;
    o.property169 = 169;
    o.property170 = 170;
    o.property171 = 171;
    o.property172 = 172;
    o.property173 = 173;
    o.property174 = 174;
    o.property175 = 175;
    o.property176 = 176;
    o.property177 = 177;
    o.property178 = 178;
    o.property179 = 179;
    o.property180 = 180;
    o.property181 = 181;
    o.property182 = 182;
    o.property183 = 183;
    o.property184 = 184;
    o.property185 = 185;
    o.property186 = 186;
    o.property187 = 187;
    o.property188 = 188;
    o.property189 = 189;
    o.property190 = 190;
    o.property191 = 191;
    o.property192 = 192;
    o.property193 = 193;
    o.property194 = 194;
    o.property195 = 195;
    o.property196 = 196;
    o.property197 = 197;
    o.property198 = 198;
    o.property199 = 199;
    o.property200 = 200;
    o.property201 = 201;
    o.property202 = 202;
    o.property203 = 203;
    o.property204 = 204;
    o.property205 = 205;
    o.property206 = 206;
    o.property207 = 207;
    o.property208 = 208;
    o.property209 = 209;
    o.property210 = 210;
    o.property211 = 211;
    o.property212 = 212;
    o.property213 = 213;
    o.property214 = 214;
    o.property215 = 215;
    o.property216 = 216;
    o.property217 = 217;
    o.property218 = 218;
    o.property219 = 219;
    o.property220 = 220;
    o.property221 = 221;
    o.property222 = 222;
    o.property223 = 223;
    o.property224 = 224;
    o.property225 = 225;
    o.property226 = 226;
    o.property227 = 227;
    o.property228 = 228;
    o.property229 = 229;
    o.property230 = 230;
    o.property231 = 231;
    o.property232 = 232;
    o.property233 = 233;
    o.property234 = 234;
    o.property235 = 235;
    o.property236 = 236;
    o.property237 = 237;
    o.property238 = 238;
    o.property239 = 239;
    o.property240 = 240;
    o.property241 = 241;
    o.property242 = 242;
    o.property243 = 243;
    o.property244 = 244;
    o.property245 = 245;
    o.property246 = 246;
    o.property247 = 247;
    o.property248 = 248;
    o.property249 = 249;
    o.property250 = 250;
    o.property251 = 251;
    o.property252 = 252;
    o.property253 = 253;
    o.property254 = 254;
    o.property255 = 255;
    o.property256 = 256;
    o.property257 = 257;
    o.property258 = 258;
    o.property259 = 259;
    o.property260 = 260;
    o.property261 = 261;
    o.property262 = 262;
    o.property263 = 263;
    o.property264 = 264;
    o.property265 = 265;
    o.property266 = 266;
    o.property267 = 267;
    o.property268 = 268;
    o.property269 = 269;
    o.property270 = 270;
    o.property271 = 271;
    o.property272 = 272;
    o.property273 = 273;
    o.property274 = 274;
    o.property275 = 275;
    o.property276 = 276;
    o.property277 = 277;
    o.property278 = 278;
    o.property279 = 279;
    o.property280 = 280;
    o.property281 = 281;
    o.property282 = 282;
    o.property283 = 283;
    o.property284 = 284;
    o.property285 = 285;
    o.property286 = 286;
    o.property287 = 287;
    o.property288 = 288;
    o.property289 = 289;
    o.property290 = 290;
    o.property291 = 291;
    o.property292 = 292;
    o.property293 = 293;
    o.property294 = 294;
    o.property295 = 295;
    o.property296 = 296;
    o.property297 = 297;
    o.property298 = 298;
    o.property299 = 299;
    o.property300 = 300;
    o.property301 = 301;
    o.property302 = 302;
    o.property303 = 303;
    o.property304 = 304;
    o.property305 = 305;
    o.property306 = 306;
    o.property307 = 307;
    o.property308 = 308;
    o.property309 = 309;
    o.property310 = 310;
    o.property311 = 311;
    o.property312 = 312;
    o.property313 = 313;
    o.property314 = 314;
    o.property315 = 315;
    o.property316 = 316;
    o.property317 = 317;
    o.property318 = 318;
    o.property319 = 319;
    o.property320 = 320;
    o.property321 = 321;
    o.property322 = 322;
    o.property323 = 323;
    o.property324 = 324;
    o.property325 = 325;
    o.property326 = 326;
    o.property327 = 327;
    o.property328 = 328;
    o.property329 = 329;
    o.property330 = 330;
    o.property331 = 331;
    o.property332 = 332;
    o.property333 = 333;
    o.property334 = 334;
    o.property335 = 335;
    o.property336 = 336;
    o.property337 = 337;
    o.property338 = 338;
    o.property339 = 339;
    o.property340 = 340;
    o.property341 = 341;
    o.property342 = 342;
    o.property343 = 343;
    o.property344 = 344;
    o.property345 = 345;
    o.property346 = 346;
    o.property347 = 347;
    o.property348 = 348;
    o.property349 = 349;
    o.property350 = 350;
    o.property351 = 351;
    o.property352 = 352;
    o.property353 = 353;
    o.property354 = 354;
    o.property355 = 355;
    o.property356 = 356;
    o.property357 = 357;
    o.property358 = 358;
    o.property359 = 359;
    o.property360 = 360;
    o.property361 = 361;
    o.property362 = 362;
    o.property363 = 363;
    o.property364 = 364;
    o.property365 = 365;
    o.property366 = 366;
    o.property367 = 367;
    o.property368 = 368;
    o.property369 = 369;
    o.property370 = 370;
    o.property371 = 371;
    o.property372 = 372;
    o.property373 = 373;
    o.property374 = 374;
    o.property375 = 375;
    o.property376 = 376;
    o.property377 = 377;
    o.property378 = 378;
    o.property379 = 379;
    o.property380 = 380;
    o.property381 = 381;
    o.property382 = 382;
    o.property383 = 383;
    o.property384 = 384;
    o.property385 = 385;
    o.property386 = 386;
    o.property387 = 387;
    o.property388 = 388;
    o.property389 = 389;
    o.property390 = 390;
    o.property391 = 391;
    o.property392 = 392;
    o.property393 = 393;
    o.property394 = 394;
    o.property395 = 395;
    o.property396 = 396;
    o.property397 = 397;
    o.property398 = 398;
    o.property399 = 399;
    o.property400 = 400;
    o.property401 = 401;
    o.property402 = 402;
    o.property403 = 403;
    o.property404 = 404;
    o.property405 = 405;
    o.property406 = 406;
    o.property407 = 407;
    o.property408 = 408;
    o.property409 = 409;
    o.property410 = 410;
    o.property411 = 411;
    o.property412 = 412;
    o.property413 = 413;
    o.property414 = 414;
    o.property415 = 415;
    o.property416 = 416;
    o.property417 = 417;
    o.property418 = 418;
    o.property419 = 419;
    o.property420 = 420;
    o.property421 = 421;
    o.property422 = 422;
    o.property423 = 423;
    o.property424 = 424;
    o.property425 = 425;
    o.property426 = 426;
    o.property427 = 427;
    o.property428 = 428;
    o.property429 = 429;
    o.property430 = 430;
    o.property431 = 431;
    o.property432 = 432;
    o.property433 = 433;
    o.property434 = 434;
    o.property435 = 435;
    o.property436 = 436;
    o.property437 = 437;
    o.property438 = 438;
    o.property439 = 439;
    o.property440 = 440;
    o.property441 = 441;
    o.property442 = 442;
    o.property443 = 443;
    o.property444 = 444;
    o.property445 = 445;
    o.property446 = 446;
    o.property447 = 447;
    o.property448 = 448;
    o.property449 = 449;
    o.property450 = 450;
    o.property451 = 451;
    o.property452 = 452;
    o.property453 = 453;
    o.property454 = 454;
    o.property455 = 455;
    o.property456 = 456;
    o.property457 = 457;
    o.property458 = 458;
    o.property459 = 459;
    o.property460 = 460;
    o.property461 = 461;
    o.property462 = 462;
    o.property463 = 463;
    o.property464 = 464;
    o.property465 = 465;
    o.property466 = 466;
    o.property467 = 467;
    o.property468 = 468;
    o.property469 = 469;
    o.property470 = 470;
    o.property471 = 471;
    o.property472 = 472;
    o.property473 = 473;
    o.property474 = 474;
    o.property475 = 475;
    o.property476 = 476;
    o.property477 = 477;
    o.property478 = 478;
    o.property479 = 479;
    o.property480 = 480;
    o.property481 = 481;
    o.property482 = 482;
    o.property483 = 483;
    o.property484 = 484;
    o.property485 = 485;
    o.property486 = 486;
    o.property487 = 487;
    o.property488 = 488;
    o.property489 = 489;
    o.property490 = 490;
    o.property491 = 491;
    o.property492 = 492;
    o.property493 = 493;
    o.property494 = 494;
    o.property495 = 495;
    o.property496 = 496;
    o.property497 = 497;
    o.property498 = 498;
    o.property499 = 499;
    o.property500 = 500;
    o.property501 = 501;
    o.property502 = 502;
    o.property503 = 503;
    o.property504 = 504;
    o.property505 = 505;
    o.property506 = 506;
    o.property507 = 507;
    o.property508 = 508;
    o.property509 = 509;
    o.property510 = 510;
    o.property511 = 511;
    o.property512 = 512;
    o.property513 = 513;
    o.property514 = 514;
    o.property515 = 515;
    o.property516 = 516;
    o.property517 = 517;
    o.property518 = 518;
    o.property519 = 519;
    o.property520 = 520;
    o.property521 = 521;
    o.property522 = 522;
    o.property523 = 523;
    o.property524 = 524;
    o.property525 = 525;
    o.property526 = 526;
    o.property527 = 527;
    o.property528 = 528;
    o.property529 = 529;
    o.property530 = 530;
    o.property531 = 531;
    o.property532 = 532;
    o.property533 = 533;
    o.property534 = 534;
    o.property535 = 535;
    o.property536 = 536;
    o.property537 = 537;
    o.property538 = 538;
    o.property539 = 539;
    o.property540 = 540;
    o.property541 = 541;
    o.property542 = 542;
    o.property543 = 543;
    o.property544 = 544;
    o.property545 = 545;
    o.property546 = 546;
    o.property547 = 547;
    o.property548 = 548;
    o.property549 = 549;
    o.property550 = 550;
    o.property551 = 551;
    o.property552 = 552;
    o.property553 = 553;
    o.property554 = 554;
    o.property555 = 555;
    o.property556 = 556;
    o.property557 = 557;
    o.property558 = 558;
    o.property559 = 559;
    o.property560 = 560;
    o.property561 = 561;
    o.property562 = 562;
    o.property563 = 563;
    o.property564 = 564;
    o.property565 = 565;
    o.property566 = 566;
    o.property567 = 567;
    o.property568 = 568;
    o.property569 = 569;
    o.property570 = 570;
    o.property571 = 571;
    o.property572 = 572;
    o.property573 = 573;
    o.property574 = 574;
    o.property575 = 575;
    o.property576 = 576;
    o.property577 = 577;
    o.property578 = 578;
    o.property579 = 579;
    o.property580 = 580;
    o.property581 = 581;
    o.property582 = 582;
    o.property583 = 583;
    o.property584 = 584;
    o.property585 = 585;
    o.property586 = 586;
    o.property587 = 587;
    o.property588 = 588;
    o.property589 = 589;
    o.property590 = 590;
    o.property591 = 591;
    o.property592 = 592;
    o.property593 = 593;
    o.property594 = 594;
    o.property595 = 595;
    o.property596 = 596;
    o.property597 = 597;
    o.property598 = 598;
    o.property599 = 599;
    o.property600 = 600;
    o.property601 = 601;
    o.property602 = 602;
    o.property603 = 603;
    o.property604 = 604;
    o.property605 = 605;
    o.property606 = 606;
    o.property607 = 607;
    o.property608 = 608;
    o.property609 = 609;
    o.property610 = 610;
    o.property611 = 611;
    o.property612 = 612;
    o.property613 = 613;
    o.property614 = 614;
    o.property615 = 615;
    o.property616 = 616;
    o.property617 = 617;
    o.property618 = 618;
    o.property619 = 619;
    o.property620 = 620;
    o.property621 = 621;
    o.property622 = 622;
    o.property623 = 623;
    o.property624 = 624;
    o.property625 = 625;
    o.property626 = 626;
    o.property627 = 627;
    o.property628 = 628;
    o.property629 = 629;
    o.property630 = 630;
    o.property631 = 631;
    o.property632 = 632;
    o.property633 = 633;
    o.property634 = 634;
    o.property635 = 635;
    o.property636 = 636;
    o.property637 = 637;
    o.property638 = 638;
    o.property639 = 639;
    o.property640 = 640;
    o.property641 = 641;
    o.property642 = 642;
    o.property643 = 643;
    o.property644 = 644;
    o.property645 = 645;
    o.property646 = 646;
    o.property647 = 647;
    o.property648 = 648;
    o.property649 = 649;
    o.property650 = 650;
    o.property651 = 651;
    o.property652 = 652;
    o.property653 = 653;
    o.property654 = 654;
    o.property655 = 655;
    o.property656 = 656;
    o.property657 = 657;
    o.property658 = 658;
    o.property659 = 659;
    o.property660 = 660;
    o.property661 = 661;
    o.property662 = 662;
    o.property663 = 663;
    o.property664 = 664;
    o.property665 = 665;
    o.property666 = 666;
    o.property667 = 667;
    o.property668 = 668;
    o.property669 = 669;
    o.property670 = 670;
    o.property671 = 671;
    o.property672 = 672;
    o.property673 = 673;
    o.property674 = 674;
    o.property675 = 675;
    o.property676 = 676;
    o.property677 = 677;
    o.property678 = 678;
    o.property679 = 679;
    o.property680 = 680;
    o.property681 = 681;
    o.property682 = 682;
    o.property683 = 683;
    o.property684 = 684;
    o.property685 = 685;
    o.property686 = 686;
    o.property687 = 687;
    o.property688 = 688;
    o.property689 = 689;
    o.property690 = 690;
    o.property691 = 691;
    o.property692 = 692;
    o.property693 = 693;
    o.property694 = 694;
    o.property695 = 695;
    o.property696 = 696;
    o.property697 = 697;
    o.property698 = 698;
    o.property699 = 699;
    o.property700 = 700;
    o.property701 = 701;
    o.property702 = 702;
    o.property703 = 703;
    o.property704 = 704;
    o.property705 = 705;
    o.property706 = 706;
    o.property707 = 707;
    o.property708 = 708;
    o.property709 = 709;
    o.property710 = 710;
    o.property711 = 711;
    o.property712 = 712;
    o.property713 = 713;
    o.property714 = 714;
    o.property715 = 715;
    o.property716 = 716;
    o.property717 = 717;
    o.property718 = 718;
    o.property719 = 719;
    o.property720 = 720;
    o.property721 = 721;
    o.property722 = 722;
    o.property723 = 723;
    o.property724 = 724;
    o.property725 = 725;
    o.property726 = 726;
    o.property727 = 727;
    o.property728 = 728;
    o.property729 = 729;
    o.property730 = 730;
    o.property731 = 731;
    o.property732 = 732;
    o.property733 = 733;
    o.property734 = 734;
    o.property735 = 735;
    o.property736 = 736;
    o.property737 = 737;
    o.property738 = 738;
    o.property739 = 739;
    o.property740 = 740;
    o.property741 = 741;
    o.property742 = 742;
    o.property743 = 743;
    o.property744 = 744;
    o.property745 = 745;
    o.property746 = 746;
    o.property747 = 747;
    o.property748 = 748;
    o.property749 = 749;
    o.property750 = 750;
    o.property751 = 751;
    o.property752 = 752;
    o.property753 = 753;
    o.property754 = 754;
    o.property755 = 755;
    o.property756 = 756;
    o.property757 = 757;
    o.property758 = 758;
    o.property759 = 759;
    o.property760 = 760;
    o.property761 = 761;
    o.property762 = 762;
    o.property763 = 763;
    o.property764 = 764;
    o.property765 = 765;
    o.property766 = 766;
    o.property767 = 767;
    o.property768 = 768;
    o.property769 = 769;
    o.property770 = 770;
    o.property771 = 771;
    o.property772 = 772;
    o.property773 = 773;
    o.property774 = 774;
    o.property775 = 775;
    o.property776 = 776;
    o.property777 = 777;
    o.property778 = 778;
    o.property779 = 779;
    o.property780 = 780;
    o.property781 = 781;
    o.property782 = 782;
    o.property783 = 783;
    o.property784 = 784;
    o.property785 = 785;
    o.property786 = 786;
    o.property787 = 787;
    o.property788 = 788;
    o.property789 = 789;
    o.property790 = 790;
    o.property791 = 791;
    o.property792 = 792;
    o.property793 = 793;
    o.property794 = 794;
    o.property795 = 795;
    o.property796 = 796;
    o.property797 = 797;
    o.property798 = 798;
    o.property799 = 799;
    o.property800 = 800;
    o.property801 = 801;
    o.property802 = 802;
    o.property803 = 803;
    o.property804 = 804;
    o.property805 = 805;
    o.property806 = 806;
    o.property807 = 807;
    o.property808 = 808;
    o.property809 = 809;
    o.property810 = 810;
    o.property811 = 811;
    o.property812 = 812;
    o.property813 = 813;
    o.property814 = 814;
    o.property815 = 815;
    o.property816 = 816;
    o.property817 = 817;
    o.property818 = 818;
    o.property819 = 819;
    o.property820 = 820;
    o.property821 = 821;
    o.property822 = 822;
    o.property823 = 823;
    o.property824 = 824;
    o.property825 = 825;
    o.property826 = 826;
    o.property827 = 827;
    o.property828 = 828;
    o.property829 = 829;
    o.property830 = 830;
    o.property831 = 831;
    o.property832 = 832;
    o.property833 = 833;
    o.property834 = 834;
    o.property835 = 835;
    o.property836 = 836;
    o.property837 = 837;
    o.property838 = 838;
    o.property839 = 839;
    o.property840 = 840;
    o.property841 = 841;
    o.property842 = 842;
    o.property843 = 843;
    o.property844 = 844;
    o.property845 = 845;
    o.property846 = 846;
    o.property847 = 847;
    o.property848 = 848;
    o.property849 = 849;
    o.property850 = 850;
    o.property851 = 851;
    o.property852 = 852;
    o.property853 = 853;
    o.property854 = 854;
    o.property855 = 855;
    o.property856 = 856;
    o.property857 = 857;
    o.property858 = 858;
    o.property859 = 859;
    o.property860 = 860;
    o.property861 = 861;
    o.property862 = 862;
    o.property863 = 863;
    o.property864 = 864;
    o.property865 = 865;
    o.property866 = 866;
    o.property867 = 867;
    o.property868 = 868;
    o.property869 = 869;
    o.property870 = 870;
    o.property871 = 871;
    o.property872 = 872;
    o.property873 = 873;
    o.property874 = 874;
    o.property875 = 875;
    o.property876 = 876;
    o.property877 = 877;
    o.property878 = 878;
    o.property879 = 879;
    o.property880 = 880;
    o.property881 = 881;
    o.property882 = 882;
    o.property883 = 883;
    o.property884 = 884;
    o.property885 = 885;
    o.property886 = 886;
    o.property887 = 887;
    o.property888 = 888;
    o.property889 = 889;
    o.property890 = 890;
    o.property891 = 891;
    o.property892 = 892;
    o.property893 = 893;
    o.property894 = 894;
    o.property895 = 895;
    o.property896 = 896;
    o.property897 = 897;
    o.property898 = 898;
    o.property899 = 899;
    o.property900 = 900;
    o.property901 = 901;
    o.property902 = 902;
    o.property903 = 903;
    o.property904 = 904;
    o.property905 = 905;
    o.property906 = 906;
    o.property907 = 907;
    o.property908 = 908;
    o.property909 = 909;
    o.property910 = 910;
    o.property911 = 911;
    o.property912 = 912;
    o.property913 = 913;
    o.property914 = 914;
    o.property915 = 915;
    o.property916 = 916;
    o.property917 = 917;
    o.property918 = 918;
    o.property919 = 919;
    o.property920 = 920;
    o.property921 = 921;
    o.property922 = 922;
    o.property923 = 923;
    o.property924 = 924;
    o.property925 = 925;
    o.property926 = 926;
    o.property927 = 927;
    o.property928 = 928;
    o.property929 = 929;
    o.property930 = 930;
    o.property931 = 931;
    o.property932 = 932;
    o.property933 = 933;
    o.property934 = 934;
    o.property935 = 935;
    o.property936 = 936;
    o.property937 = 937;
    o.property938 = 938;
    o.property939 = 939;
    o.property940 = 940;
    o.property941 = 941;
    o.property942 = 942;
    o.property943 = 943;
    o.property944 = 944;
    o.property945 = 945;
    o.property946 = 946;
    o.property947 = 947;
    o.property948 = 948;
    o.property949 = 949;
    o.property950 = 950;
    o.property951 = 951;
    o.property952 = 952;
    o.property953 = 953;
    o.property954 = 954;
    o.property955 = 955;
    o.property956 = 956;
    o.property957 = 957;
    o.property958 = 958;
    o.property959 = 959;
    o.property960 = 960;
    o.property961 = 961;
    o.property962 = 962;
    o.property963 = 963;
    o.property964 = 964;
    o.property965 = 965;
    o.property966 = 966;
    o.property967 = 967;
    o.property968 = 968;
    o.property969 = 969;
    o.property970 = 970;
    o.property971 = 971;
    o.property972 = 972;
    o.property973 = 973;
    o.property974 = 974;
    o.property975 = 975;
    o.property976 = 976;
    o.property977 = 977;
    o.property978 = 978;
    o.property979 = 979;
    o.property980 = 980;
    o.property981 = 981;
    o.property982 = 982;
    o.property983 = 983;
    o.property984 = 984;
    o.property985 = 985;
    o.property986 = 986;
    o.property987 = 987;
    o.property988 = 988;
    o.property989 = 989;
    o.property990 = 990;
    o.property991 = 991;
    o.property992 = 992;
    o.property993 = 993;
    o.property994 = 994;
    o.property995 = 995;
    o.property996 = 996;
    o.property997 = 997;
    o.property998 = 998;
    o.property999 = 999;
    o.property1000 = 1000;
}

function test3() {
    function Foo() {
        this.property1 = 1;
        this.property2 = 2;
        this.property3 = 3;
        this.property4 = 4;
        this.property5 = 5;
        this.property6 = 6;
        this.property7 = 7;
        this.property8 = 8;
        this.property9 = 9;
        this.property10 = 10;
        this.property11 = 11;
        this.property12 = 12;
        this.property13 = 13;
        this.property14 = 14;
        this.property15 = 15;
        this.property16 = 16;
        this.property17 = 17;
        this.property18 = 18;
        this.property19 = 19;
        this.property20 = 20;
        this.property21 = 21;
        this.property22 = 22;
        this.property23 = 23;
        this.property24 = 24;
        this.property25 = 25;
        this.property26 = 26;
        this.property27 = 27;
        this.property28 = 28;
        this.property29 = 29;
        this.property30 = 30;
        this.property31 = 31;
        this.property32 = 32;
        this.property33 = 33;
        this.property34 = 34;
        this.property35 = 35;
        this.property36 = 36;
        this.property37 = 37;
        this.property38 = 38;
        this.property39 = 39;
        this.property40 = 40;
        this.property41 = 41;
        this.property42 = 42;
        this.property43 = 43;
        this.property44 = 44;
        this.property45 = 45;
        this.property46 = 46;
        this.property47 = 47;
        this.property48 = 48;
        this.property49 = 49;
        this.property50 = 50;
        this.property51 = 51;
        this.property52 = 52;
        this.property53 = 53;
        this.property54 = 54;
        this.property55 = 55;
        this.property56 = 56;
        this.property57 = 57;
        this.property58 = 58;
        this.property59 = 59;
        this.property60 = 60;
        this.property61 = 61;
        this.property62 = 62;
        this.property63 = 63;
        this.property64 = 64;
        this.property65 = 65;
        this.property66 = 66;
        this.property67 = 67;
        this.property68 = 68;
        this.property69 = 69;
        this.property70 = 70;
        this.property71 = 71;
        this.property72 = 72;
        this.property73 = 73;
        this.property74 = 74;
        this.property75 = 75;
        this.property76 = 76;
        this.property77 = 77;
        this.property78 = 78;
        this.property79 = 79;
        this.property80 = 80;
        this.property81 = 81;
        this.property82 = 82;
        this.property83 = 83;
        this.property84 = 84;
        this.property85 = 85;
        this.property86 = 86;
        this.property87 = 87;
        this.property88 = 88;
        this.property89 = 89;
        this.property90 = 90;
        this.property91 = 91;
        this.property92 = 92;
        this.property93 = 93;
        this.property94 = 94;
        this.property95 = 95;
        this.property96 = 96;
        this.property97 = 97;
        this.property98 = 98;
        this.property99 = 99;
        this.property100 = 100;
        this.property101 = 101;
        this.property102 = 102;
        this.property103 = 103;
        this.property104 = 104;
        this.property105 = 105;
        this.property106 = 106;
        this.property107 = 107;
        this.property108 = 108;
        this.property109 = 109;
        this.property110 = 110;
        this.property111 = 111;
        this.property112 = 112;
        this.property113 = 113;
        this.property114 = 114;
        this.property115 = 115;
        this.property116 = 116;
        this.property117 = 117;
        this.property118 = 118;
        this.property119 = 119;
        this.property120 = 120;
        this.property121 = 121;
        this.property122 = 122;
        this.property123 = 123;
        this.property124 = 124;
        this.property125 = 125;
        this.property126 = 126;
        this.property127 = 127;
        this.property128 = 128;
        this.property129 = 129;
        this.property130 = 130;
        this.property131 = 131;
        this.property132 = 132;
        this.property133 = 133;
        this.property134 = 134;
        this.property135 = 135;
        this.property136 = 136;
        this.property137 = 137;
        this.property138 = 138;
        this.property139 = 139;
        this.property140 = 140;
        this.property141 = 141;
        this.property142 = 142;
        this.property143 = 143;
        this.property144 = 144;
        this.property145 = 145;
        this.property146 = 146;
        this.property147 = 147;
        this.property148 = 148;
        this.property149 = 149;
        this.property150 = 150;
        this.property151 = 151;
        this.property152 = 152;
        this.property153 = 153;
        this.property154 = 154;
        this.property155 = 155;
        this.property156 = 156;
        this.property157 = 157;
        this.property158 = 158;
        this.property159 = 159;
        this.property160 = 160;
        this.property161 = 161;
        this.property162 = 162;
        this.property163 = 163;
        this.property164 = 164;
        this.property165 = 165;
        this.property166 = 166;
        this.property167 = 167;
        this.property168 = 168;
        this.property169 = 169;
        this.property170 = 170;
        this.property171 = 171;
        this.property172 = 172;
        this.property173 = 173;
        this.property174 = 174;
        this.property175 = 175;
        this.property176 = 176;
        this.property177 = 177;
        this.property178 = 178;
        this.property179 = 179;
        this.property180 = 180;
        this.property181 = 181;
        this.property182 = 182;
        this.property183 = 183;
        this.property184 = 184;
        this.property185 = 185;
        this.property186 = 186;
        this.property187 = 187;
        this.property188 = 188;
        this.property189 = 189;
        this.property190 = 190;
        this.property191 = 191;
        this.property192 = 192;
        this.property193 = 193;
        this.property194 = 194;
        this.property195 = 195;
        this.property196 = 196;
        this.property197 = 197;
        this.property198 = 198;
        this.property199 = 199;
        this.property200 = 200;
        this.property201 = 201;
        this.property202 = 202;
        this.property203 = 203;
        this.property204 = 204;
        this.property205 = 205;
        this.property206 = 206;
        this.property207 = 207;
        this.property208 = 208;
        this.property209 = 209;
        this.property210 = 210;
        this.property211 = 211;
        this.property212 = 212;
        this.property213 = 213;
        this.property214 = 214;
        this.property215 = 215;
        this.property216 = 216;
        this.property217 = 217;
        this.property218 = 218;
        this.property219 = 219;
        this.property220 = 220;
        this.property221 = 221;
        this.property222 = 222;
        this.property223 = 223;
        this.property224 = 224;
        this.property225 = 225;
        this.property226 = 226;
        this.property227 = 227;
        this.property228 = 228;
        this.property229 = 229;
        this.property230 = 230;
        this.property231 = 231;
        this.property232 = 232;
        this.property233 = 233;
        this.property234 = 234;
        this.property235 = 235;
        this.property236 = 236;
        this.property237 = 237;
        this.property238 = 238;
        this.property239 = 239;
        this.property240 = 240;
        this.property241 = 241;
        this.property242 = 242;
        this.property243 = 243;
        this.property244 = 244;
        this.property245 = 245;
        this.property246 = 246;
        this.property247 = 247;
        this.property248 = 248;
        this.property249 = 249;
        this.property250 = 250;
        this.property251 = 251;
        this.property252 = 252;
        this.property253 = 253;
        this.property254 = 254;
        this.property255 = 255;
        this.property256 = 256;
        this.property257 = 257;
        this.property258 = 258;
        this.property259 = 259;
        this.property260 = 260;
        this.property261 = 261;
        this.property262 = 262;
        this.property263 = 263;
        this.property264 = 264;
        this.property265 = 265;
        this.property266 = 266;
        this.property267 = 267;
        this.property268 = 268;
        this.property269 = 269;
        this.property270 = 270;
        this.property271 = 271;
        this.property272 = 272;
        this.property273 = 273;
        this.property274 = 274;
        this.property275 = 275;
        this.property276 = 276;
        this.property277 = 277;
        this.property278 = 278;
        this.property279 = 279;
        this.property280 = 280;
        this.property281 = 281;
        this.property282 = 282;
        this.property283 = 283;
        this.property284 = 284;
        this.property285 = 285;
        this.property286 = 286;
        this.property287 = 287;
        this.property288 = 288;
        this.property289 = 289;
        this.property290 = 290;
        this.property291 = 291;
        this.property292 = 292;
        this.property293 = 293;
        this.property294 = 294;
        this.property295 = 295;
        this.property296 = 296;
        this.property297 = 297;
        this.property298 = 298;
        this.property299 = 299;
        this.property300 = 300;
        this.property301 = 301;
        this.property302 = 302;
        this.property303 = 303;
        this.property304 = 304;
        this.property305 = 305;
        this.property306 = 306;
        this.property307 = 307;
        this.property308 = 308;
        this.property309 = 309;
        this.property310 = 310;
        this.property311 = 311;
        this.property312 = 312;
        this.property313 = 313;
        this.property314 = 314;
        this.property315 = 315;
        this.property316 = 316;
        this.property317 = 317;
        this.property318 = 318;
        this.property319 = 319;
        this.property320 = 320;
        this.property321 = 321;
        this.property322 = 322;
        this.property323 = 323;
        this.property324 = 324;
        this.property325 = 325;
        this.property326 = 326;
        this.property327 = 327;
        this.property328 = 328;
        this.property329 = 329;
        this.property330 = 330;
        this.property331 = 331;
        this.property332 = 332;
        this.property333 = 333;
        this.property334 = 334;
        this.property335 = 335;
        this.property336 = 336;
        this.property337 = 337;
        this.property338 = 338;
        this.property339 = 339;
        this.property340 = 340;
        this.property341 = 341;
        this.property342 = 342;
        this.property343 = 343;
        this.property344 = 344;
        this.property345 = 345;
        this.property346 = 346;
        this.property347 = 347;
        this.property348 = 348;
        this.property349 = 349;
        this.property350 = 350;
        this.property351 = 351;
        this.property352 = 352;
        this.property353 = 353;
        this.property354 = 354;
        this.property355 = 355;
        this.property356 = 356;
        this.property357 = 357;
        this.property358 = 358;
        this.property359 = 359;
        this.property360 = 360;
        this.property361 = 361;
        this.property362 = 362;
        this.property363 = 363;
        this.property364 = 364;
        this.property365 = 365;
        this.property366 = 366;
        this.property367 = 367;
        this.property368 = 368;
        this.property369 = 369;
        this.property370 = 370;
        this.property371 = 371;
        this.property372 = 372;
        this.property373 = 373;
        this.property374 = 374;
        this.property375 = 375;
        this.property376 = 376;
        this.property377 = 377;
        this.property378 = 378;
        this.property379 = 379;
        this.property380 = 380;
        this.property381 = 381;
        this.property382 = 382;
        this.property383 = 383;
        this.property384 = 384;
        this.property385 = 385;
        this.property386 = 386;
        this.property387 = 387;
        this.property388 = 388;
        this.property389 = 389;
        this.property390 = 390;
        this.property391 = 391;
        this.property392 = 392;
        this.property393 = 393;
        this.property394 = 394;
        this.property395 = 395;
        this.property396 = 396;
        this.property397 = 397;
        this.property398 = 398;
        this.property399 = 399;
        this.property400 = 400;
        this.property401 = 401;
        this.property402 = 402;
        this.property403 = 403;
        this.property404 = 404;
        this.property405 = 405;
        this.property406 = 406;
        this.property407 = 407;
        this.property408 = 408;
        this.property409 = 409;
        this.property410 = 410;
        this.property411 = 411;
        this.property412 = 412;
        this.property413 = 413;
        this.property414 = 414;
        this.property415 = 415;
        this.property416 = 416;
        this.property417 = 417;
        this.property418 = 418;
        this.property419 = 419;
        this.property420 = 420;
        this.property421 = 421;
        this.property422 = 422;
        this.property423 = 423;
        this.property424 = 424;
        this.property425 = 425;
        this.property426 = 426;
        this.property427 = 427;
        this.property428 = 428;
        this.property429 = 429;
        this.property430 = 430;
        this.property431 = 431;
        this.property432 = 432;
        this.property433 = 433;
        this.property434 = 434;
        this.property435 = 435;
        this.property436 = 436;
        this.property437 = 437;
        this.property438 = 438;
        this.property439 = 439;
        this.property440 = 440;
        this.property441 = 441;
        this.property442 = 442;
        this.property443 = 443;
        this.property444 = 444;
        this.property445 = 445;
        this.property446 = 446;
        this.property447 = 447;
        this.property448 = 448;
        this.property449 = 449;
        this.property450 = 450;
        this.property451 = 451;
        this.property452 = 452;
        this.property453 = 453;
        this.property454 = 454;
        this.property455 = 455;
        this.property456 = 456;
        this.property457 = 457;
        this.property458 = 458;
        this.property459 = 459;
        this.property460 = 460;
        this.property461 = 461;
        this.property462 = 462;
        this.property463 = 463;
        this.property464 = 464;
        this.property465 = 465;
        this.property466 = 466;
        this.property467 = 467;
        this.property468 = 468;
        this.property469 = 469;
        this.property470 = 470;
        this.property471 = 471;
        this.property472 = 472;
        this.property473 = 473;
        this.property474 = 474;
        this.property475 = 475;
        this.property476 = 476;
        this.property477 = 477;
        this.property478 = 478;
        this.property479 = 479;
        this.property480 = 480;
        this.property481 = 481;
        this.property482 = 482;
        this.property483 = 483;
        this.property484 = 484;
        this.property485 = 485;
        this.property486 = 486;
        this.property487 = 487;
        this.property488 = 488;
        this.property489 = 489;
        this.property490 = 490;
        this.property491 = 491;
        this.property492 = 492;
        this.property493 = 493;
        this.property494 = 494;
        this.property495 = 495;
        this.property496 = 496;
        this.property497 = 497;
        this.property498 = 498;
        this.property499 = 499;
        this.property500 = 500;
        this.property501 = 501;
        this.property502 = 502;
        this.property503 = 503;
        this.property504 = 504;
        this.property505 = 505;
        this.property506 = 506;
        this.property507 = 507;
        this.property508 = 508;
        this.property509 = 509;
        this.property510 = 510;
        this.property511 = 511;
        this.property512 = 512;
        this.property513 = 513;
        this.property514 = 514;
        this.property515 = 515;
        this.property516 = 516;
        this.property517 = 517;
        this.property518 = 518;
        this.property519 = 519;
        this.property520 = 520;
        this.property521 = 521;
        this.property522 = 522;
        this.property523 = 523;
        this.property524 = 524;
        this.property525 = 525;
        this.property526 = 526;
        this.property527 = 527;
        this.property528 = 528;
        this.property529 = 529;
        this.property530 = 530;
        this.property531 = 531;
        this.property532 = 532;
        this.property533 = 533;
        this.property534 = 534;
        this.property535 = 535;
        this.property536 = 536;
        this.property537 = 537;
        this.property538 = 538;
        this.property539 = 539;
        this.property540 = 540;
        this.property541 = 541;
        this.property542 = 542;
        this.property543 = 543;
        this.property544 = 544;
        this.property545 = 545;
        this.property546 = 546;
        this.property547 = 547;
        this.property548 = 548;
        this.property549 = 549;
        this.property550 = 550;
        this.property551 = 551;
        this.property552 = 552;
        this.property553 = 553;
        this.property554 = 554;
        this.property555 = 555;
        this.property556 = 556;
        this.property557 = 557;
        this.property558 = 558;
        this.property559 = 559;
        this.property560 = 560;
        this.property561 = 561;
        this.property562 = 562;
        this.property563 = 563;
        this.property564 = 564;
        this.property565 = 565;
        this.property566 = 566;
        this.property567 = 567;
        this.property568 = 568;
        this.property569 = 569;
        this.property570 = 570;
        this.property571 = 571;
        this.property572 = 572;
        this.property573 = 573;
        this.property574 = 574;
        this.property575 = 575;
        this.property576 = 576;
        this.property577 = 577;
        this.property578 = 578;
        this.property579 = 579;
        this.property580 = 580;
        this.property581 = 581;
        this.property582 = 582;
        this.property583 = 583;
        this.property584 = 584;
        this.property585 = 585;
        this.property586 = 586;
        this.property587 = 587;
        this.property588 = 588;
        this.property589 = 589;
        this.property590 = 590;
        this.property591 = 591;
        this.property592 = 592;
        this.property593 = 593;
        this.property594 = 594;
        this.property595 = 595;
        this.property596 = 596;
        this.property597 = 597;
        this.property598 = 598;
        this.property599 = 599;
        this.property600 = 600;
        this.property601 = 601;
        this.property602 = 602;
        this.property603 = 603;
        this.property604 = 604;
        this.property605 = 605;
        this.property606 = 606;
        this.property607 = 607;
        this.property608 = 608;
        this.property609 = 609;
        this.property610 = 610;
        this.property611 = 611;
        this.property612 = 612;
        this.property613 = 613;
        this.property614 = 614;
        this.property615 = 615;
        this.property616 = 616;
        this.property617 = 617;
        this.property618 = 618;
        this.property619 = 619;
        this.property620 = 620;
        this.property621 = 621;
        this.property622 = 622;
        this.property623 = 623;
        this.property624 = 624;
        this.property625 = 625;
        this.property626 = 626;
        this.property627 = 627;
        this.property628 = 628;
        this.property629 = 629;
        this.property630 = 630;
        this.property631 = 631;
        this.property632 = 632;
        this.property633 = 633;
        this.property634 = 634;
        this.property635 = 635;
        this.property636 = 636;
        this.property637 = 637;
        this.property638 = 638;
        this.property639 = 639;
        this.property640 = 640;
        this.property641 = 641;
        this.property642 = 642;
        this.property643 = 643;
        this.property644 = 644;
        this.property645 = 645;
        this.property646 = 646;
        this.property647 = 647;
        this.property648 = 648;
        this.property649 = 649;
        this.property650 = 650;
        this.property651 = 651;
        this.property652 = 652;
        this.property653 = 653;
        this.property654 = 654;
        this.property655 = 655;
        this.property656 = 656;
        this.property657 = 657;
        this.property658 = 658;
        this.property659 = 659;
        this.property660 = 660;
        this.property661 = 661;
        this.property662 = 662;
        this.property663 = 663;
        this.property664 = 664;
        this.property665 = 665;
        this.property666 = 666;
        this.property667 = 667;
        this.property668 = 668;
        this.property669 = 669;
        this.property670 = 670;
        this.property671 = 671;
        this.property672 = 672;
        this.property673 = 673;
        this.property674 = 674;
        this.property675 = 675;
        this.property676 = 676;
        this.property677 = 677;
        this.property678 = 678;
        this.property679 = 679;
        this.property680 = 680;
        this.property681 = 681;
        this.property682 = 682;
        this.property683 = 683;
        this.property684 = 684;
        this.property685 = 685;
        this.property686 = 686;
        this.property687 = 687;
        this.property688 = 688;
        this.property689 = 689;
        this.property690 = 690;
        this.property691 = 691;
        this.property692 = 692;
        this.property693 = 693;
        this.property694 = 694;
        this.property695 = 695;
        this.property696 = 696;
        this.property697 = 697;
        this.property698 = 698;
        this.property699 = 699;
        this.property700 = 700;
        this.property701 = 701;
        this.property702 = 702;
        this.property703 = 703;
        this.property704 = 704;
        this.property705 = 705;
        this.property706 = 706;
        this.property707 = 707;
        this.property708 = 708;
        this.property709 = 709;
        this.property710 = 710;
        this.property711 = 711;
        this.property712 = 712;
        this.property713 = 713;
        this.property714 = 714;
        this.property715 = 715;
        this.property716 = 716;
        this.property717 = 717;
        this.property718 = 718;
        this.property719 = 719;
        this.property720 = 720;
        this.property721 = 721;
        this.property722 = 722;
        this.property723 = 723;
        this.property724 = 724;
        this.property725 = 725;
        this.property726 = 726;
        this.property727 = 727;
        this.property728 = 728;
        this.property729 = 729;
        this.property730 = 730;
        this.property731 = 731;
        this.property732 = 732;
        this.property733 = 733;
        this.property734 = 734;
        this.property735 = 735;
        this.property736 = 736;
        this.property737 = 737;
        this.property738 = 738;
        this.property739 = 739;
        this.property740 = 740;
        this.property741 = 741;
        this.property742 = 742;
        this.property743 = 743;
        this.property744 = 744;
        this.property745 = 745;
        this.property746 = 746;
        this.property747 = 747;
        this.property748 = 748;
        this.property749 = 749;
        this.property750 = 750;
        this.property751 = 751;
        this.property752 = 752;
        this.property753 = 753;
        this.property754 = 754;
        this.property755 = 755;
        this.property756 = 756;
        this.property757 = 757;
        this.property758 = 758;
        this.property759 = 759;
        this.property760 = 760;
        this.property761 = 761;
        this.property762 = 762;
        this.property763 = 763;
        this.property764 = 764;
        this.property765 = 765;
        this.property766 = 766;
        this.property767 = 767;
        this.property768 = 768;
        this.property769 = 769;
        this.property770 = 770;
        this.property771 = 771;
        this.property772 = 772;
        this.property773 = 773;
        this.property774 = 774;
        this.property775 = 775;
        this.property776 = 776;
        this.property777 = 777;
        this.property778 = 778;
        this.property779 = 779;
        this.property780 = 780;
        this.property781 = 781;
        this.property782 = 782;
        this.property783 = 783;
        this.property784 = 784;
        this.property785 = 785;
        this.property786 = 786;
        this.property787 = 787;
        this.property788 = 788;
        this.property789 = 789;
        this.property790 = 790;
        this.property791 = 791;
        this.property792 = 792;
        this.property793 = 793;
        this.property794 = 794;
        this.property795 = 795;
        this.property796 = 796;
        this.property797 = 797;
        this.property798 = 798;
        this.property799 = 799;
        this.property800 = 800;
        this.property801 = 801;
        this.property802 = 802;
        this.property803 = 803;
        this.property804 = 804;
        this.property805 = 805;
        this.property806 = 806;
        this.property807 = 807;
        this.property808 = 808;
        this.property809 = 809;
        this.property810 = 810;
        this.property811 = 811;
        this.property812 = 812;
        this.property813 = 813;
        this.property814 = 814;
        this.property815 = 815;
        this.property816 = 816;
        this.property817 = 817;
        this.property818 = 818;
        this.property819 = 819;
        this.property820 = 820;
        this.property821 = 821;
        this.property822 = 822;
        this.property823 = 823;
        this.property824 = 824;
        this.property825 = 825;
        this.property826 = 826;
        this.property827 = 827;
        this.property828 = 828;
        this.property829 = 829;
        this.property830 = 830;
        this.property831 = 831;
        this.property832 = 832;
        this.property833 = 833;
        this.property834 = 834;
        this.property835 = 835;
        this.property836 = 836;
        this.property837 = 837;
        this.property838 = 838;
        this.property839 = 839;
        this.property840 = 840;
        this.property841 = 841;
        this.property842 = 842;
        this.property843 = 843;
        this.property844 = 844;
        this.property845 = 845;
        this.property846 = 846;
        this.property847 = 847;
        this.property848 = 848;
        this.property849 = 849;
        this.property850 = 850;
        this.property851 = 851;
        this.property852 = 852;
        this.property853 = 853;
        this.property854 = 854;
        this.property855 = 855;
        this.property856 = 856;
        this.property857 = 857;
        this.property858 = 858;
        this.property859 = 859;
        this.property860 = 860;
        this.property861 = 861;
        this.property862 = 862;
        this.property863 = 863;
        this.property864 = 864;
        this.property865 = 865;
        this.property866 = 866;
        this.property867 = 867;
        this.property868 = 868;
        this.property869 = 869;
        this.property870 = 870;
        this.property871 = 871;
        this.property872 = 872;
        this.property873 = 873;
        this.property874 = 874;
        this.property875 = 875;
        this.property876 = 876;
        this.property877 = 877;
        this.property878 = 878;
        this.property879 = 879;
        this.property880 = 880;
        this.property881 = 881;
        this.property882 = 882;
        this.property883 = 883;
        this.property884 = 884;
        this.property885 = 885;
        this.property886 = 886;
        this.property887 = 887;
        this.property888 = 888;
        this.property889 = 889;
        this.property890 = 890;
        this.property891 = 891;
        this.property892 = 892;
        this.property893 = 893;
        this.property894 = 894;
        this.property895 = 895;
        this.property896 = 896;
        this.property897 = 897;
        this.property898 = 898;
        this.property899 = 899;
        this.property900 = 900;
        this.property901 = 901;
        this.property902 = 902;
        this.property903 = 903;
        this.property904 = 904;
        this.property905 = 905;
        this.property906 = 906;
        this.property907 = 907;
        this.property908 = 908;
        this.property909 = 909;
        this.property910 = 910;
        this.property911 = 911;
        this.property912 = 912;
        this.property913 = 913;
        this.property914 = 914;
        this.property915 = 915;
        this.property916 = 916;
        this.property917 = 917;
        this.property918 = 918;
        this.property919 = 919;
        this.property920 = 920;
        this.property921 = 921;
        this.property922 = 922;
        this.property923 = 923;
        this.property924 = 924;
        this.property925 = 925;
        this.property926 = 926;
        this.property927 = 927;
        this.property928 = 928;
        this.property929 = 929;
        this.property930 = 930;
        this.property931 = 931;
        this.property932 = 932;
        this.property933 = 933;
        this.property934 = 934;
        this.property935 = 935;
        this.property936 = 936;
        this.property937 = 937;
        this.property938 = 938;
        this.property939 = 939;
        this.property940 = 940;
        this.property941 = 941;
        this.property942 = 942;
        this.property943 = 943;
        this.property944 = 944;
        this.property945 = 945;
        this.property946 = 946;
        this.property947 = 947;
        this.property948 = 948;
        this.property949 = 949;
        this.property950 = 950;
        this.property951 = 951;
        this.property952 = 952;
        this.property953 = 953;
        this.property954 = 954;
        this.property955 = 955;
        this.property956 = 956;
        this.property957 = 957;
        this.property958 = 958;
        this.property959 = 959;
        this.property960 = 960;
        this.property961 = 961;
        this.property962 = 962;
        this.property963 = 963;
        this.property964 = 964;
        this.property965 = 965;
        this.property966 = 966;
        this.property967 = 967;
        this.property968 = 968;
        this.property969 = 969;
        this.property970 = 970;
        this.property971 = 971;
        this.property972 = 972;
        this.property973 = 973;
        this.property974 = 974;
        this.property975 = 975;
        this.property976 = 976;
        this.property977 = 977;
        this.property978 = 978;
        this.property979 = 979;
        this.property980 = 980;
        this.property981 = 981;
        this.property982 = 982;
        this.property983 = 983;
        this.property984 = 984;
        this.property985 = 985;
        this.property986 = 986;
        this.property987 = 987;
        this.property988 = 988;
        this.property989 = 989;
        this.property990 = 990;
        this.property991 = 991;
        this.property992 = 992;
        this.property993 = 993;
        this.property994 = 994;
        this.property995 = 995;
        this.property996 = 996;
        this.property997 = 997;
        this.property998 = 998;
        this.property999 = 999;
        this.property1000 = 1000;
    }
    new Foo();
}

test1();
test2();
test3();
