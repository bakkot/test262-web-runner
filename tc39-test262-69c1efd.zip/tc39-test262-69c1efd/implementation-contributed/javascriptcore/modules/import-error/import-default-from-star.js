import A from "./export-default-from-star.js"
