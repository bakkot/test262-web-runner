
export const A = 20;
