export const A = 42;

export * from "./export-ambiguous-1.js"
export * from "./export-ambiguous-2.js"
