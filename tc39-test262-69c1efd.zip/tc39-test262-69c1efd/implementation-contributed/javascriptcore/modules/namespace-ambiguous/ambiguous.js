import * as namespace from "ambiguous-2.js"
