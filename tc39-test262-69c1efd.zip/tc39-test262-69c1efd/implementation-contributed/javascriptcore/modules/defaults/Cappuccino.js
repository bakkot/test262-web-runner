
var Cappuccino = 'Cappuccino';

export { Cappuccino as default }
