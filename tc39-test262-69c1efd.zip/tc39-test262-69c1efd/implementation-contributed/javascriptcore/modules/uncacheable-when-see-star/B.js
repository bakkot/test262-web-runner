export let A = 40;
