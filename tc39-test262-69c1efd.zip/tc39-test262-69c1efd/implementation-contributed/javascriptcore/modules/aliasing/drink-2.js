export let Cappuccino = "Cappuccino"

export function changeCappuccino(value) {
    Cappuccino = value;
}
