import * as namespace from "./namespace-tdz/main.js"
