export const B = 50;
export const C = 50;
