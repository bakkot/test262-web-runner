export let async = 42;
