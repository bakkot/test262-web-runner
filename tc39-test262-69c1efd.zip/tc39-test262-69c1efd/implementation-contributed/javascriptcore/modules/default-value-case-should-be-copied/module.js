let value = 42;

export default value;

export function changeValue(v) {
    value = v;
}
