export const A = 42;
export const B = 50
