import A from "./indirect-export-default-2.js"
export { A }
