export const A = 42;
