export * from "indirect-export-default-3.js"
