export let Cocoa = "Cocoa", Cappuccino = "Cappuccino";

export const Matcha = "Matcha", Mocha = "Mocha";
