import drinkCocoa from './cocoa.js'

export default function drinkCappuccino()
{
    return drinkCocoa();
}
