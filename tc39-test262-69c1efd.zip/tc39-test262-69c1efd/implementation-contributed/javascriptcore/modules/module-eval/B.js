import { A } from "./A.js"

export let B = "B";
