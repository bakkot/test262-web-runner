export const Cocoa = "Cocoa";

export let Cappuccino = "Cappuccino";
