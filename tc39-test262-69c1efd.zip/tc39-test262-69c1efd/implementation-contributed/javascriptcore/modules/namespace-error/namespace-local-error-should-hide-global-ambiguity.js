import * as namespace from "./namespace-local-error-should-hide-global-ambiguity-2.js"
