export * from "./namespace-local-error-should-hide-global-ambiguity-6.js"
import Hello from "./namespace-local-error-should-hide-global-ambiguity-7.js"
export { Hello }
