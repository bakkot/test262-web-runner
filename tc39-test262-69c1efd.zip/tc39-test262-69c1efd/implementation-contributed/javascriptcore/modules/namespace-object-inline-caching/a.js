export let goodbye = 0;
